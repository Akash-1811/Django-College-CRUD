from django.db import models


# Create your models here.
class Student_Register(models.Model):
    name=models.CharField(max_length=20)
    std_id=models.IntegerField(default=0)
    stream=models.CharField(max_length=20)
    mobile=models.CharField(max_length=12,default=0)
    is_deleted=models.CharField(max_length=2,default='no')
