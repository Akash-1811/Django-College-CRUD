from Student import views
from django.urls import path

urlpatterns = [
    path('home/', views.home),
    path('data/',views.data),
    path('delete/<int:tid>',views.delete),
    path('update/<int:tid>',views.update)
]
