from django.shortcuts import render,redirect
from Student.models import Student_Register

# Create your views here.
def home(request):
    if (request.method=='POST'):
        name_=request.POST['name']
        std_id_=request.POST['std_id']
        stream_=request.POST['stream']
        mobile_=request.POST['mobile']

        print(mobile_)

        insert_data=Student_Register.objects.create(name=name_,std_id=std_id_,stream=stream_,mobile=mobile_)
        insert_data.save()

        return redirect('/')

    return render(request,'Student/home.html')

def data(request):
    content={}
    content['data']=Student_Register.objects.filter(is_deleted='no')

    return render(request,'Student/data.html',content)

def delete(request,tid):
    record_to_delete=Student_Register.objects.filter(id=tid)
    record_to_delete.update(is_deleted='y')

    return redirect('/')

def update(request,tid):
    if request.method=='POST':
        name_=request.POST['name']
        std_id_=request.POST['std_id']
        stream_=request.POST['stream']
        mobile_=request.POST['mobile']

        record_to_update=Student_Register.objects.filter(id=tid)
        record_to_update.update(name=name_,std_id=std_id_,stream=stream_,mobile=mobile_)

        return redirect('/')

    else:
        content={}
        content['data']=Student_Register.objects.get(id=tid)
        return render(request,'Student/update.html',content)
